"""
US3C_LR
US full dataset (1991-2014), 3-class training (class 0/1/2).
predict_risk() returns P(class=1) -- probability of actual default.
"""
from pathlib import Path
import joblib
import numpy as np
import pandas as pd


class Model:
    """US3C_LR: pre-trained on US full data, 3-class."""

    def __init__(self):
        base   = Path(__file__).resolve().parent
        meta   = joblib.load(base / "train_meta.pkl")
        self.feature_cols = meta["FEATURE_COLS"]
        self.medians      = meta["medians"]

        obj = joblib.load(base / "lr.pkl")
        if isinstance(obj, dict) and "scaler" in obj:
            self.scaler = obj["scaler"]
            self.clf    = obj["model"]
        else:
            self.scaler = None
            self.clf    = obj

        # sklearn 1.6.x predict_proba still reads self.multi_class internally;
        # models saved with sklearn 1.7+ no longer have this attribute.
        if not hasattr(self.clf, "multi_class"):
            try: self.clf.multi_class = "auto"
            except AttributeError: pass

        # Same patch for the scaler in case it has version-specific gaps
        if self.scaler is not None and not hasattr(self.scaler, "multi_class"):
            pass  # StandardScaler has no multi_class; no patch needed

    def _prepare_X(self, X):
        frame = X.copy() if isinstance(X, pd.DataFrame) else pd.DataFrame(X)
        for col in self.feature_cols:
            if col not in frame.columns:
                frame[col] = np.nan
        frame = frame[self.feature_cols].copy()
        for col in self.feature_cols:
            frame[col] = pd.to_numeric(frame[col], errors="coerce").fillna(
                self.medians.get(col, 0.0)
            )
        return frame.astype(np.float32)

    def fit(self, X_train, durations=None, events=None):
        """Pre-trained model -- fit() is a no-op."""
        return self

    def predict_risk(self, X_test, horizons=[12]):
        X = self._prepare_X(X_test)
        if self.scaler is not None:
            X = self.scaler.transform(X)
        proba = self.clf.predict_proba(X)   # shape (n, 3)
        risk  = proba[:, 1]                 # P(class=1): actual default
        risk  = np.clip(risk, 0.0, 1.0)
        return pd.DataFrame({"risk_12": risk})
