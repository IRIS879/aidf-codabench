import os
import pickle
import numpy as np

class model:
    def __init__(self):
        self.is_trained = False
        self.classifier = None 

    def fit(self, X, y):
        print("====== [选手代码] 开始训练模型 ======")
        # 这里写你真正的训练逻辑，比如：
        # from sklearn.ensemble import RandomForestClassifier
        # self.classifier = RandomForestClassifier()
        # self.classifier.fit(X, y)
        self.is_trained = True
        print("====== [选手代码] 模型训练成功！ ======")

    def predict(self, X):
        print(f"====== [选手代码] 正在进行预测，数据维度: {X.shape} ======")
        
        # 1. 正常的模型预测（注意：Iris 数据集有 3 个类别，所以返回预测概率矩阵的第二维是 3）
        # 如果有真实模型，换成：preds = self.classifier.predict_proba(X)
        preds = np.zeros((X.shape[0], 3)) 
        
        # 2. 🚨 重点：不要自己在 predict 里通过代码强行写盘了 🚨
        # 只要确保返回这个矩阵即可。平台的主办方脚本（ingestion.py）拿到这个 return 之后，
        # 会在 /app/output 下自动帮你把这个矩阵保存为名为 predictions.csv 的标准表格。
        return preds

    def save(self, path):
        """ 持久化保存模型，防止 ingestion 框架报错 """
        if os.path.isdir(path):
            filename = os.path.join(path, 'model.pickle')
        else:
            filename = path
        with open(filename, 'wb') as f:
            pickle.dump(self, f)

    def load(self, path):
        """ 保底恢复模型规范 """
        if os.path.isdir(path):
            filename = os.path.join(path, 'model.pickle')
        else:
            filename = path
        if os.path.exists(filename):
            with open(filename, 'rb') as f:
                tmp_model = pickle.load(f)
                self.__dict__.update(tmp_model.__dict__)