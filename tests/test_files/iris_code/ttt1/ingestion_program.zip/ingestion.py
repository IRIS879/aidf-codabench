#!/usr/bin/env python
import sys
import os
import shutil

# --- 强制路径注入 (Force Injection) ---
# 这是最底层的方案，直接绕过环境变量和相对路径
TARGET_PATH = '/app/program'
if TARGET_PATH not in sys.path:
    sys.path.insert(0, TARGET_PATH)

print(f"[AIDF DEBUG] Python Path: {sys.path}")
print(f"[AIDF DEBUG] Current Working Dir: {os.getcwd()}")
print(f"[AIDF DEBUG] Files in /app/program: {os.listdir('/app/program')}")

# --- 尝试导入 ---
try:
    import data_io
    from data_manager import DataManager
    from model import model
    print("[AIDF SUCCESS] 平台库加载成功！")
except Exception as e:
    print(f"[AIDF CRITICAL] 导入失败! 错误: {e}")
    sys.exit(1)

# =========================== MAIN ==========================================

if __name__ == "__main__":
    # 1. 确保读取命令行传入的路径 (平台会自动传入 4 个参数)
    if len(argv) < 5:
        print(f"[ERROR] Expected 4 arguments, got {len(argv)-1}. Check system call.")
        sys.exit(1)
        
    input_dir = os.path.abspath(argv[1])
    output_dir = os.path.abspath(argv[2])
    program_dir = os.path.abspath(argv[3])
    submission_dir = os.path.abspath(argv[4])

    print(f"[DEBUG] input_dir: {input_dir}")
    print(f"[DEBUG] output_dir: {output_dir}")

    # 将目录加入 Python 搜索路径，以便 import 选手代码
    path.append(program_dir)
    path.append(submission_dir)

    # 确保输出目录存在
    data_io.mkdir(output_dir)

    # 2. 数据盘点
    datanames = data_io.inventory_data(input_dir)
    
    # 3. 核心循环
    for basename in datanames:
        print(f"\n========== Processing: {basename} ==========\n")
        start_time = time.time()

        # 加载数据
        D = DataManager(basename, input_dir, replace_missing=True, verbose=True)
        
        # 初始化时间 budget 变量，解决 NameError
        time_budget = D.info.get('time_budget', 500)
        
        # 训练模型
        M = model()
        M.fit(D.data['X_train'], D.data['Y_train'])
        
        # 预测
        Y_test = M.predict(D.data['X_test'])
        
        # 保存结果到 output
        pred_path = os.path.join(output_dir, f"{basename}_test.predict")
        data_io.write(pred_path, Y_test)
        
        # ⚠️ 【强制同步】手动搬运文件到评分器预期路径
        # 无论平台命名怎么纠结，直接在评分输入目录放一份硬编码命名文件
        try:
            # 兼容 iris_test 命名要求
            manual_sync_path = os.path.join(submission_dir, "iris_test.predict")
            shutil.copyfile(pred_path, manual_sync_path)
            print(f"[SUCCESS] Manually staged: {manual_sync_path}")
        except Exception as e:
            print(f"[WARNING] Manual staging failed: {e}")

        # 检查耗时
        time_spent = time.time() - start_time
        print(f"[+] Prediction finished in {time_spent:.2f} seconds.")
        
        if time_budget - time_spent <= 0:
            print("[-] Time budget exceeded, breaking.")
            break

    print("[+] Ingestion finished safely.")