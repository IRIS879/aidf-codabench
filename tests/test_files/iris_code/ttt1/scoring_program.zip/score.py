#!/usr/bin/env python

# Scoring program for the AutoML challenge
import os
import sys
import yaml
import libscores
from libscores import ls, filesep, mkdir, read_array, compute_all_scores, write_scores

# 默认参数
missing_score = -0.999999
scoring_version = 1.0

def _HERE(*args):
    h = os.path.dirname(os.path.realpath(__file__))
    return os.path.join(h, *args)

def _load_scoring_function():
    with open(_HERE('metric.txt'), 'r') as f:
        metric_name = f.readline().strip()
        return metric_name, getattr(libscores, metric_name)

if __name__ == "__main__":
    # 1. 动态获取目录，不使用硬编码路径
    if len(sys.argv) == 3:
        input_dir = sys.argv[1]
        output_dir = sys.argv[2]
    else:
        # 如果参数缺失，打印调试信息
        print("Usage: score.py <input_dir> <output_dir>")
        sys.exit(1)

    mkdir(output_dir)
    score_file = open(os.path.join(output_dir, 'scores.txt'), 'w')
    html_file = open(os.path.join(output_dir, 'scores.html'), 'w')

    metric_name, scoring_function = _load_scoring_function()

    # 2. 获取 solution 文件列表
    ref_dir = os.path.join(input_dir, 'ref')
    solution_names = sorted(ls(os.path.join(ref_dir, '*.solution')))
    
    print(f"DEBUG: Found {len(solution_names)} solution files in {ref_dir}")

    for i, solution_file in enumerate(solution_names):
        set_num = i + 1
        score_name = 'set%s_score' % set_num
        basename = os.path.basename(solution_file).split('.')[0]

        try:
            # 3. 增强版预测文件查找：防止 list index out of range
            res_dir = os.path.join(input_dir, 'res')
            predict_pattern = os.path.join(res_dir, basename + '*.predict')
            predict_files = ls(predict_pattern)
            
            if not predict_files:
                raise IOError(f"No prediction file found for basename '{basename}' in {res_dir}")
            
            predict_file = predict_files[-1]
            predict_name = os.path.basename(predict_file).split('.')[0]
            
            print(f"DEBUG: Processing {basename}, using {predict_name}")

            solution = read_array(solution_file)
            prediction = read_array(predict_file)
            
            if (solution.shape != prediction.shape):
                raise ValueError(f"Shape mismatch! Pred: {prediction.shape}, Sol: {solution.shape}")

            score = scoring_function(solution, prediction)
            
            print(f"======= Set {set_num} ({predict_name.capitalize()}): score({score_name})={score:0.12f} =======")
            html_file.write(f"======= Set {set_num} ({predict_name.capitalize()}): score({score_name})={score:0.12f} =======\n")

        except Exception as inst:
            score = missing_score
            print(f"======= Set {set_num} ({basename.capitalize()}): score({score_name})=ERROR =======")
            print(f"DEBUG: Detailed Error: {inst}")
            html_file.write(f"======= Set {set_num} ({basename.capitalize()}): score({score_name})=ERROR =======\n")
            html_file.write(f"Error: {str(inst)}\n")

        score_file.write(f"{score_name}: {score:0.12f}\n")

    # Metadata 处理
    try:
        metadata_path = os.path.join(input_dir, 'res', 'metadata')
        with open(metadata_path, 'r') as f:
            metadata = yaml.safe_load(f)
            score_file.write("Duration: %0.6f\n" % metadata.get('elapsedTime', 0))
    except:
        score_file.write("Duration: 0\n")

    html_file.close()
    score_file.close()